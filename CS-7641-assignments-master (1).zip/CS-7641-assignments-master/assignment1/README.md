# Assignment 1 - Supervised Learning

There is nothing extra to do here, just pick your datasets, start running, and come back in a week.